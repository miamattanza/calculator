# SVG Icon Pack — Расходы и доходы

60 настоящих SVG-иконок в едином стиле серии 6: неравномерная гранёная форма, витражная мозаика, глубокие jewel-цвета, золотистые швы и светлая пиктограмма.

## Структура
- `*.svg` — 60 отдельных векторных иконок.
- `states.css` — пример состояний кнопки без дублирования SVG.
- `manifest.csv` — slug, русское название и тип пиктограммы.

## Технические параметры
- viewBox: `0 0 96 96`
- SVG, масштабирование без потери качества.
- Единая визуальная толщина основных контуров.
- Пиктограммы выполнены геометрическими `path`, `circle`, `rect`, `polygon`.
- Цвета вынесены в атрибуты SVG для простого редактирования.
- Состояния Normal / Pressed / Selected / Disabled лучше делать стилями компонента, а не отдельными файлами.

## Важно
Это самостоятельная векторная реконструкция выбранного нами визуального направления серии 6. Сгенерированное ранее PNG-изображение было референсом стиля, а не исходным векторным материалом.

## Список
- `groceries.svg` — Продукты
- `restaurants.svg` — Рестораны
- `coffee.svg` — Кофе
- `coffee_takeaway.svg` — Кофе с собой
- `housing.svg` — Жильё
- `utilities.svg` — Коммунальные услуги
- `internet_tv.svg` — Интернет и ТВ
- `mobile.svg` — Мобильная связь
- `public_transport.svg` — Общественный транспорт
- `taxi.svg` — Такси
- `fuel.svg` — Топливо
- `parking.svg` — Парковка
- `car.svg` — Автомобиль
- `car_service.svg` — Автосервис
- `car_insurance.svg` — Страховка авто
- `car_wash.svg` — Мойка
- `flights.svg` — Авиабилеты
- `rail.svg` — Ж/д билеты
- `hotel.svg` — Отели
- `travel.svg` — Путешествия
- `tourism.svg` — Туризм
- `pharmacy.svg` — Аптеки
- `doctors.svg` — Врачи
- `dentistry.svg` — Стоматология
- `tests.svg` — Анализы
- `health.svg` — Здоровье
- `sport.svg` — Спорт
- `fitness.svg` — Фитнес
- `clothing.svg` — Одежда
- `shoes.svg` — Обувь
- `accessories.svg` — Аксессуары
- `perfume.svg` — Парфюм
- `cosmetics.svg` — Косметика
- `beauty.svg` — Салон красоты
- `selfcare.svg` — Уход за собой
- `education.svg` — Обучение
- `books.svg` — Книги
- `courses.svg` — Курсы
- `hobbies.svg` — Хобби
- `games.svg` — Игры
- `cinema.svg` — Кино
- `music.svg` — Музыка
- `subscriptions.svg` — Подписки
- `software.svg` — Софт
- `home_interior.svg` — Дом и интерьер
- `furniture.svg` — Мебель
- `appliances.svg` — Бытовая техника
- `electronics.svg` — Электроника
- `phone.svg` — Телефон
- `gifts.svg` — Подарки
- `flowers.svg` — Цветы
- `children.svg` — Дети
- `pets.svg` — Домашние животные
- `charity.svg` — Благотворительность
- `investments.svg` — Инвестиции
- `income.svg` — Доходы
- `salary.svg` — Зарплата
- `freelance.svg` — Фриланс
- `sales.svg` — Продажи
- `bonuses.svg` — Бонусы